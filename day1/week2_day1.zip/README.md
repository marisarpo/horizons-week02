# Week 2 Day 1 Exercises

## Pair programming exercises

1. [Setup week02 Git repository](git.md)
1. CSS Selectors: Complete the [CSS Diner](http://flukeout.github.io/) exercise
1. [Horello](horello/README.md)
1. [Clone Any Landing Page](clone/README.md)
1. [Bonus: CSS Challenge](css_challenge/README.md)

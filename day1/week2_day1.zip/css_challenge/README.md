# CSS challenge: animated buttons and icons

## Instructions

1. Create the button with the jiggle effect at
   https://scotch.io/bar-talk/codepen-challenge-1-css-jiggly-button using only
   CSS.
2. Create the animated GIF icon at
   https://www.sitepoint.com/challenge-1-recreate-gif-css/ using only CSS.

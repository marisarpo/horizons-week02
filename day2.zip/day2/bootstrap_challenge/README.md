# Challenge: Bootstrap

## Instructions

Recreate [this page](http://bragthemes.com/demo/pinstrap/) (the
Pinterest responsive grid system) using Bootstrap. ("Pinstrap" is
Pinterest meets Bootstrap.)


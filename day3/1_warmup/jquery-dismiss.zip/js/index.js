// 1. Add a click hander to 'x' button
// 2. Inside the click handler find the alert div and make it disappear using $.hide()

// YOUR CODE HERE
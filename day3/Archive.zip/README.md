# Week 2, Day 3 Exercises: jQuery, how I love thee

## Inline Exercises

1. [Single click hander](http://codepen.io/moose-horizons/pen/rWbVjj?editors=1011)
1. [Many click handlers](http://codepen.io/moose-horizons/pen/WoWvpN?editors=1010)
1. [Image selector](http://codepen.io/rick-shar/pen/rjzmbY?editors=1010) 

## Pair Programming Exercises

1. [Collapsible comment threads](comment_threads/README.md)
1. [Making Horello dynamic](horello_dynamic/README.md)
1. [Bonus: jQuery challenges](bonus_jquery.md)
